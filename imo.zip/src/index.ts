import './js/App.ts';
import './styles/input.css';


require.context('./assets/icons', true, /\.svg$/);
