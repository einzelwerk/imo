import Alpine from 'alpinejs';
// eslint-disable-next-line
import { register } from 'swiper/element/bundle';
import {Navigation, EffectFade} from 'swiper'
// eslint-disable-next-line
import 'swiper/css'

register();

const infoSlider = document.querySelector('.js-info-slider');
const params = {
  modules: [Navigation, EffectFade],

};

Object.assign(infoSlider, params);

infoSlider.initialize();

declare global {
  // eslint-disable-next-line
  interface Window {
    Alpine: unknown;
  }
}

window.Alpine = Alpine;

Alpine.start();
